import random
import tkinter as tk
from tkinter import messagebox
import pyperclip

# ---------------------------- PASSWORD GENERATOR ------------------------------- #
def generate_password():
    entry_pass.delete(0, tk.END)
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
               'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
               'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+', '-']

    letter_list = [random.choice(letters) for i in range(random.randint(8, 10))]
    symbol_list = [random.choice(symbols) for i in range(random.randint(2, 4))]
    num_list = [random.choice(numbers) for i in range(random.randint(2, 4))]

    password_list = letter_list + symbol_list + num_list
    random.shuffle(password_list)

    password = "".join(password_list)
    entry_pass.insert(0, password)
    pyperclip.copy(password)



# ---------------------------- SAVE PASSWORD ------------------------------- #



# ---------------------------- UI SETUP ------------------------------- #





def add_data():
    website = entry_website.get()
    email = entry_email.get()
    password = entry_pass.get()

    if len(website) == 0 or len(email) == 0 or len(password) == 0:
        messagebox.showinfo(title="Oops!", message="Please don't leave any fields empty!")
    else:
        is_ok = messagebox.askokcancel(title=website, message="Is this data ok to save?")
        if is_ok:
            with open("info.txt", mode="a") as file:
                file.write(f"{website} | {email} | {password}\n")
                entry_website.delete(0, tk.END)
                entry_email.delete(0, tk.END)
                entry_pass.delete(0, tk.END)


window = tk.Tk()
window.title("Password Manager")
window.config(padx=20, pady=20)

canvas = tk.Canvas(width=200, height=200)
logo_img = tk.PhotoImage(file="logo.png")
canvas.create_image(100, 100, image=logo_img)
canvas.grid(column=1, row=0)

# Labels
label_website = tk.Label(text="Website:")
label_website.grid(column=0, row=1)
label_email = tk.Label(text="Email/Username:")
label_email.grid(column=0, row=2)
label_pass = tk.Label(text="Password:")
label_pass.grid(column=0, row=3)

# Entries
entry_website = tk.Entry(width=35)
entry_website.grid(column=1, row=1, columnspan=2, sticky="EW")
entry_website.focus()
entry_email = tk.Entry(width=35)
entry_email.grid(column=1, row=2, columnspan=2, sticky="EW")
entry_pass = tk.Entry(width=35)
entry_pass.grid(column=1, row=3)

# Buttons
button_gen_pass = tk.Button(text="Generate Password", command=generate_password)
button_gen_pass.grid(column=2, row=3, sticky="EW")
button_add = tk.Button(text="Add", width=35, command=add_data)
button_add.grid(column=1, row=4, columnspan=2, sticky="EW")

window.mainloop()




