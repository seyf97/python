from turtle import Turtle
WIDTH = 1000
HEIGHT = 600
X_PAD = 20

class Paddle(Turtle):
    def __init__(self, pad_num):
        super().__init__()
        self.shape("square")
        self.penup()
        self.shapesize(stretch_len=0.25, stretch_wid=2)
        self.color("white")
        self.speed("fastest")

        #LEFT IS 1, RIGHT IS 2
        if pad_num == 1:
            self.goto(-WIDTH / 2 + X_PAD, 0)
        elif pad_num == 2:
            self.goto(WIDTH / 2 - X_PAD, 0)

    def up(self):
        self.goto(self.xcor(), self.ycor()+20)

    def down(self):
        self.goto(self.xcor(), self.ycor()-20)
