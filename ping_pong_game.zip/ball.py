from turtle import Turtle
import random


class Ball(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.penup()
        self.shapesize(stretch_len=0.5, stretch_wid=0.5)
        self.color("white")
        self.speed("fastest")
        self.throw_ball()



    def bounce_wall(self):
        self.setheading(-self.heading())

    def bounce_paddle(self):
        self.setheading(-self.heading()+180)

    def throw_ball(self):
        # Ball either going to the right or left side
        heading = random.randint(0, 359)
        self.setheading(heading)

    def refresh(self):
        self.goto(0, 0)
        self.throw_ball()
