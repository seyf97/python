from turtle import Screen, Turtle
from paddle import Paddle
from ball import Ball
from scoreboard import Scoreboard
import time

WIDTH = 1000
HEIGHT = 600

screen = Screen()
screen.setup(width=WIDTH, height=HEIGHT)
screen.bgcolor("black")
screen.title("Pong Game")
screen.tracer(0)

dashed_line = Turtle()
dashed_line.hideturtle()
dashed_line.color("white")
dashed_line.penup()
dashed_line.setheading(90)
dashed_line.goto(0, -HEIGHT/2)
dashed_line.pensize(5)

for i in range(0, HEIGHT, 20):
    if i%40 == 0:
        dashed_line.pendown()
        dashed_line.forward(HEIGHT/20)
    else:
        dashed_line.penup()
        dashed_line.forward(HEIGHT/20)


# LEFT PLAYER
paddle_l = Paddle(1)
scoreboard_l = Scoreboard(1)

# RIGHT PLAYER
paddle_r = Paddle(2)
scoreboard_r = Scoreboard(2)

ball = Ball()

screen.update()
screen.listen()
screen.onkey(paddle_l.up, "Up")
screen.onkey(paddle_l.down, "Down")
screen.onkey(paddle_r.up, "w")
screen.onkey(paddle_r.down, "s")

X_PAD = 10 * paddle_l.shapesize()[0]


is_game_on = True
while is_game_on:
    screen.update()
    time.sleep(0.01)
    ball.forward(4)

    #Ball hits the wall
    #Subtracted amount is padding
    if ball.ycor()>=(HEIGHT/2)-5 or ball.ycor()<=-(HEIGHT/2)+5:
        ball.bounce_wall()

    # Ball hits the right paddle
    if ball.xcor() >= (WIDTH/2)-X_PAD-5:
        if paddle_r.ycor()+20 >= ball.ycor() >= paddle_r.ycor()-20:
            ball.bounce_paddle()
        else:
            ball.refresh()
            scoreboard_l.increase_score()
    # Ball hits the left paddle
    elif ball.xcor() <= -(WIDTH/2)+X_PAD+5:
        if paddle_l.ycor()+20 >= ball.ycor() >= paddle_l.ycor()-20:
            ball.bounce_paddle()
        else:
            ball.refresh()
            scoreboard_r.increase_score()


print(paddle_l.shapesize())
print(ball.shapesize())


screen.exitonclick()


#This whole thing took me around 1:30hrs...
