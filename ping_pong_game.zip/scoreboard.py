from turtle import Turtle
WIDTH = 1000
HEIGHT = 600
ALIGNMENT = "center"
FONT = ("Comic Sans", 50, "normal")


class Scoreboard(Turtle):
    def __init__(self, pad_num):
        super().__init__()
        self.score = 0
        self.color("white")
        self.hideturtle()
        self.penup()

        # LEFT SCORE
        if pad_num == 1:
            self.goto(-50, HEIGHT/2 - 70)
        # Right Score
        elif pad_num == 2:
            self.goto(+50, HEIGHT / 2 - 70)
        self.write_score()

    def write_score(self):
        self.write(f"{self.score}", False, align=ALIGNMENT, font=FONT)

    def increase_score(self):
        self.clear()
        self.score += 1
        self.write_score()



